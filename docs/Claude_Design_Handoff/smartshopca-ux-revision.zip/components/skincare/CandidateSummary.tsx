import type { SkincareCandidate } from '@/types/editorial';
import { formatCad, formatDate, unitPrice } from '@/lib/format';

/**
 * Compact, skimmable product summary: exact name and pack, dated price with
 * unit basis, one fit statement, the main trade-off and the critical evidence
 * gap. Its only action points to the product's full evidence on the same
 * page — never a purchase link.
 */
export function CandidateSummary({ candidate: c }: { candidate: SkincareCandidate }) {
  const headingId = `p-${c.id}-h`;
  const unit = unitPrice(c.price, c.amount);
  const held = c.status !== 'published' || c.holdReasons.length > 0;

  return (
    <article
      id={`p-${c.id}`}
      aria-labelledby={headingId}
      className="flex scroll-mt-6 flex-col gap-3 rounded-[14px] border border-line bg-paper p-5 sm:p-6"
    >
      {held ? (
        <p className="inline-flex items-center gap-2 self-start rounded-full bg-rust-tint px-3 py-1 text-sm font-semibold text-rust-dark">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
            <path d="M8 5v14M16 5v14" />
          </svg>
          Still checking — not a recommendation
        </p>
      ) : null}
      <div>
        <h3 id={headingId} className="heading-display text-[22px] sm:text-[24px]">
          {c.productName}
        </h3>
        <p className="text-[15px] text-ink-muted">
          {c.format} · {c.variant}
        </p>
      </div>
      <p className="flex flex-wrap items-baseline gap-x-3">
        <span className="text-[24px] font-bold">{formatCad(c.price.amountCad)}</span>
        <span className="text-[15px] text-ink-body">{unit.label}</span>
      </p>
      <p className="-mt-2 text-sm text-ink-muted">
        {c.price.priceType === 'regular' ? 'Regular' : 'Sale'} price on {formatDate(c.price.checked)}, before tax and
        shipping
      </p>
      <dl className="flex flex-col gap-2.5 text-[15px]">
        {c.chooseIf[0] ? (
          <div>
            <dt className="font-bold">Fits if</dt>
            <dd className="text-ink-body">{c.chooseIf[0]}</dd>
          </div>
        ) : null}
        {c.tradeOffs[0] ? (
          <div>
            <dt className="font-bold">Trade-off</dt>
            <dd className="text-ink-body">{c.tradeOffs[0]}</dd>
          </div>
        ) : null}
        {c.holdReasons.length ? (
          <div className="rounded-lg border border-dashed border-rust-dark px-3 py-2">
            <dt className="font-bold text-rust-dark">Evidence gap</dt>
            <dd>
              <ul className="flex flex-col">
                {c.holdReasons.map((r) => (
                  <li key={r}>{r}</li>
                ))}
              </ul>
            </dd>
          </div>
        ) : null}
      </dl>
      <a href={`#details-${c.id}`} className="mt-auto self-start py-1 font-semibold text-sage-dark">
        Evidence and sources for {c.brand}
        <span aria-hidden="true"> ↓</span>
      </a>
    </article>
  );
}
