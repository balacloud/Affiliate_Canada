'use client';

import { useEffect } from 'react';

/**
 * Progressive enhancement: when the URL hash targets a closed <details>
 * (e.g. #details-<id> from a product summary link), open it and bring it into
 * view. Without JavaScript the link still scrolls to the visible <summary>,
 * and every word inside the panel is already in the server HTML.
 */
export function OpenDetailsOnHash() {
  useEffect(() => {
    function openTarget() {
      const id = decodeURIComponent(window.location.hash.slice(1));
      if (!id) return;
      const el = document.getElementById(id);
      const details = el instanceof HTMLDetailsElement ? el : el?.closest('details');
      if (details && !details.open) {
        details.open = true;
        el?.scrollIntoView({ block: 'start' });
      }
    }
    openTarget();
    window.addEventListener('hashchange', openTarget);
    return () => window.removeEventListener('hashchange', openTarget);
  }, []);
  return null;
}
