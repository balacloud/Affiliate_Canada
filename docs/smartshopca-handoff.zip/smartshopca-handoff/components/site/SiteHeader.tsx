import Link from 'next/link';
import { primaryNav } from '@/config/site';
import { Wordmark } from './Wordmark';
import { MobileNav } from './MobileNav';
import { PillarDot } from '@/components/editorial/PillarDot';

/** Shared header. Server component; only the mobile menu is a client island. */
export function SiteHeader() {
  return (
    <header className="relative border-b border-line bg-ivory">
      <div className="container-page flex min-h-[72px] items-center justify-between gap-6">
        <Wordmark />
        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-7 text-[15px]">
            {primaryNav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="flex min-h-[44px] items-center gap-2 text-ink no-underline hover:underline"
                >
                  {item.pillar ? <PillarDot pillar={item.pillar} /> : null}
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <MobileNav items={primaryNav.map(({ href, fullLabel }) => ({ href, label: fullLabel }))} />
      </div>
    </header>
  );
}
